=========
Maybrain
=========

Rest format

Some text intro

	some code


*italics* and **bold** and ``monospace``

A section 
=========

A sub-section
-------------

Numbered lists 

1. item here

2. item here


some more text


Lists

* number one

* number two indent
  properly

