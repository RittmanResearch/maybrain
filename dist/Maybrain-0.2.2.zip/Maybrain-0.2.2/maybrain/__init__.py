# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 14:43:01 2013

@author: martyn

Initialisation file for maybrain

"""

from mayBrainTools import *
from mbplot import *
import writeFns
import mayBrainExtraFns
from recipes import *


write = writeFns.writeFns()
