# -*- coding: utf-8 -*-
"""

Initialisation for unittests of maybrain

"""
