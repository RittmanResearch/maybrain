# -*- coding: utf-8 -*-

# to create MANIFEST file, python setup.py sdist

from distutils.core import setup

setup(
    name='Maybrain', 
    version='0.2.2',
    author='Martyn Rittman and Timothy Rittman',
    author_email='mrittman@physics.org',
    packages=['maybrain', 'maybrain.test', 'maybrain.maybrainGUI'],
    scripts=['brainObjs.py','plot.py', 'extraFns.py','recipes.py','writeFns.py'],
    url='http://code.google.com/p/maybrain/',
    license='LICENSE.txt',
    description=' ',
    long_description=open('README.txt').read(),
    install_requires=[
        'networkX == v',
        'nibabel >= v',
        'numpy >= v',
        'mayavi == '
    ],
)

